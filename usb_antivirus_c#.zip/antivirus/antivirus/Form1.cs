﻿using System;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace antivirus
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private int viruses = 0;
        protected override void WndProc(ref Message msg) // Проверяем флешку
        {
            int WM_DEVICECHANGE = 537;
            IntPtr flashOut = (IntPtr)32772;
            IntPtr flashIn = (IntPtr)32768;
            if(msg.Msg == WM_DEVICECHANGE)
            {
                if(msg.WParam == flashIn) // Выставили флешку
                {
                    DriveInfo[] drives = DriveInfo.GetDrives(); // Получаем информацию о флешке
                    foreach(DriveInfo drive in drives)
                    {
                        if(drive.IsReady && drive.DriveType == DriveType.Removable) textBox2.Text = drive.Name; // Указываем путь флешки
                    }
                    textBox1.Text = ("Флешка обнаружена");
                    viruses = 0;
                    Viruses.Text = "Угроз обнаружено: " + viruses.ToString();
                    progressBar1.Value = 0;
                    listBox1.Items.Clear();
                }
                if(msg.WParam == flashOut) textBox1.Text = ("Флешка не обнаружена"); // Вытащили флешку
            }
            base.WndProc(ref msg);
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void PathButton_Click(object sender, EventArgs e)
        {
            DriveInfo[] drives = DriveInfo.GetDrives(); // Получаем информацию о флешке
            foreach (DriveInfo drive in drives)
            {
                if(drive.IsReady && drive.DriveType == DriveType.Removable) // Проверяем флешку
                {
                    string[] search = Directory.GetFiles(drive.Name);
                    progressBar1.Maximum = search.Length;
                    foreach (string item in search)
                    {
                        try
                        {
                            StreamReader stream = new StreamReader(item);
                            string read = stream.ReadToEnd();
                            string[] virus = new string[] { "trojan", "virus" };
                            foreach (string st in virus)
                            {
                                if (Regex.IsMatch(read, st))
                                {
                                    viruses += 1;
                                    Viruses.Text = "Угроз обнаружено: " + viruses.ToString();
                                    listBox1.Items.Add(item);
                                }
                                progressBar1.Increment(1);
                            }
                        }
                        catch
                        {
                            string read = item;
                            string[] virus = new string[] { "trojan", "virus" };
                            foreach (string st in virus)
                            {
                                if (Regex.IsMatch(read, st))
                                {
                                    viruses += 1;
                                    Viruses.Text = "Угроз обнаружено: " + viruses.ToString();
                                    listBox1.Items.Add(item);
                                }
                                progressBar1.Increment(1);
                            }
                        }
                    }

                }

            }
        }
        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}